<?php

return [
    'profile' => [
        'menu' => 'My Profile',
        'page' => 'My Profile',
    ],

    'settings' => [
        'menu' => 'Account Settings',
        'page' => 'Account Settings',
    ],

    'supports' => [
        'menu' => 'Help and Support',
        'page' => 'Help and Support',
    ],
];
