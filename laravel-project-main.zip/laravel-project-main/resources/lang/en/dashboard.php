<?php

return [
    'menu' => 'Dashboard',

    'routes' => [
        'index' => 'Dashboard',
    ],

    'welcome-notice' => 'Welcome Back :user',
    'update-notice' => 'The App has been updated, please reload the page',
];
