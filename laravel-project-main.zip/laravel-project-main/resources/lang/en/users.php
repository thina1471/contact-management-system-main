<?php

return [
    'menu' => 'Manage Users',

    'routes' => [
        'index' => 'All Users',
    ],

    'table' => [
        'name' => 'Nama',
        'email' => 'Email',
    ],

    'fields' => [],
];
