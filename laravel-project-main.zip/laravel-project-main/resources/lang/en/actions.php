<?php

return [
    'tables' => [
        'column' => 'Actions',
    ],

    'no-content' => 'Loading',

    'forms' => [
        'submit' => 'Submit',
        'save' => 'Save',
        'update' => 'Update',
        'cancel' => 'Cancel',
    ],
];
