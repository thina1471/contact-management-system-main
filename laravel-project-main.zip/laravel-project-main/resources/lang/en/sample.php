<?php

return [
    'menu' => 'Sample Menu',

    'routes' => [
        'index' => 'Sample Page',
    ],
];
