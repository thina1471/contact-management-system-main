<?php

return [
    'menu' => 'Kelola Pengguna',

    'routes' => [
        'index' => 'Semua Pengguna',
    ],

    'table' => [
        'name' => 'Nama',
        'email' => 'Email',
    ],

    'fields' => [],
];
