<?php

return [
    'tables' => [
        'column' => 'Aksi',
    ],

    'no-content' => 'Loading',

    'forms' => [
        'submit' => 'Kirim',
        'save' => 'Simpan',
        'update' => 'Perbarui',
        'cancel' => 'Batal',
    ],
];
