<?php

return [
    'menu' => 'Dashboard',

    'routes' => [
        'index' => 'Dashboard',
    ],

    'welcome-notice' => 'Selamat datang :user',
    'update-notice' => 'Aplikasi telah diperbarui, silakan muat ulang halaman',
];
