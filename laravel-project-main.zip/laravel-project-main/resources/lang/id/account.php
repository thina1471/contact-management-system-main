<?php

return [
    'profile' => [
        'menu' => 'Profil Saya',
        'page' => 'Profil Saya',
    ],

    'settings' => [
        'menu' => 'Pengaturan Akun',
        'page' => 'Pengaturan Akun',
    ],

    'supports' => [
        'menu' => 'Bantuan dan Dukungan',
        'page' => 'Bantuan dan Dukungan',
    ],
];
