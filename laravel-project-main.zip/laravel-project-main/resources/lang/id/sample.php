<?php

return [
    'menu' => 'Contoh Menu',

    'routes' => [
        'index' => 'Contoh Halaman',
    ],
];
