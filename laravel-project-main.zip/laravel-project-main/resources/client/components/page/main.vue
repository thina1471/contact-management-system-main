<script setup lang="ts">
</script>

<template>
  <main class="w-full flex-grow">
    <div class="container py-3 md:mx-auto">
      <slot />
    </div>
  </main>
</template>
