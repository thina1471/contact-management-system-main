<script setup lang="ts">
defineOptions({
  pageName: 'account.profile.page',
})
</script>

<template>
  <h3>Your Profile Goes Here</h3>
</template>
