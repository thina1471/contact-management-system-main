<script setup lang="ts">
defineOptions({
  pageName: 'account.settings.page',
})
</script>

<template>
  <h3>Your Account Settings Goes Here</h3>
</template>
