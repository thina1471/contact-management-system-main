<script setup lang="ts">
defineOptions({
  pageName: 'account.settings.page',
})
</script>

<template>
  <h3>User form goes here</h3>
</template>
