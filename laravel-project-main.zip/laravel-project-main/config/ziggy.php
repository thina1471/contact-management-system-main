<?php

return [
    'except' => ['debugbar.*', 'horizon.*', 'dusk.*', 'ignition.*', 'telescope'],
];
