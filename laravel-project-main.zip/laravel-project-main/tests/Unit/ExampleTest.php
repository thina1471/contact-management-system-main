<?php

namespace Tests\Unit;

use Tests\TestCase;

class ExampleTest extends TestCase
{
    /**
     * @test
     */
    public function that_true_is_true()
    {
        $this->assertTrue(true);
    }
}
