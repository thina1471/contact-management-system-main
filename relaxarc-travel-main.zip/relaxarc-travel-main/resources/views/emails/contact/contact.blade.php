@component('mail::message')
## Message from : {{ $name }} ( {{ $email }} )

### {{ $message }}
@endcomponent