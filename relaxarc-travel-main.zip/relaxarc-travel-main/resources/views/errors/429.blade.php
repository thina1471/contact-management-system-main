@extends('errors::minimal')

@section('title', __('errors.429.title'))
@section('code', '429')
@section('message', __('errors.429.text'))
