@extends('errors::minimal')

@section('title', __('errors.503.title'))
@section('code', '503')
@section('message', __('errors.503.text'))
