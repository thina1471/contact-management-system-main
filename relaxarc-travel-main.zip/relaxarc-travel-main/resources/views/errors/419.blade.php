@extends('errors::minimal')

@section('title', __('errors.419.title'))
@section('code', '419')
@section('message', __('errors.419.text'))
